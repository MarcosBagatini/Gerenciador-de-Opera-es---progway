import static java.lang.Float.parseFloat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Interface extends javax.swing.JFrame {

    String nome, moedaPO, moedaPC;
    double num, tax, valorPO, valorPC;
    int cont = 0;
    double valorT = 0, valorTemp = 0, taxaC = 0;

    ArrayList<String> nomeP = new ArrayList<>();
    ArrayList<String> taxaP = new ArrayList<>();
    ArrayList<Date> dataC = new ArrayList<>();
    ArrayList<String> ajusteO = new ArrayList<>();
    ArrayList<String> ajusteD = new ArrayList<>();

    public Interface() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField2 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        MoedaO = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        Caixa = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        MoedaD = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        nomeC = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        taxa = new javax.swing.JTextField();
        data = new com.toedter.calendar.JDateChooser();
        jButton3 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabela = new javax.swing.JTable();
        NomeTemp = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        DataTemp = new com.toedter.calendar.JDateChooser();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jvalorT = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        TaxaCobrada = new javax.swing.JTextField();
        jButton4 = new javax.swing.JButton();

        jTextField2.setText("jTextField2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Muito Dineheiro - Calculadora de Câmbio");
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setResizable(false);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("GERENCIADOR DE OPERAÇÕES");

        MoedaO.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Real (BRL)", "Dolar (USD)", "Euro (EUR)", "Peso Chileno (CLP)" }));
        MoedaO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MoedaOActionPerformed(evt);
            }
        });

        jLabel2.setText("    Moeda de Origem:");

        jLabel3.setText("    Quantidade:");

        Caixa.setText("123");
        Caixa.setName(""); // NOI18N
        Caixa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CaixaActionPerformed(evt);
            }
        });

        jLabel4.setText("    Moeda de Destino:");

        MoedaD.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Dolar (USD)", "Real (BRL)", "Euro (EUR)", "Peso Chileno (CLP)" }));
        MoedaD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MoedaDActionPerformed(evt);
            }
        });

        jButton1.setText("Converter");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Tahoma", 2, 11)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Muito dinheiro");

        jButton2.setText("Informações");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel6.setText("    Nome:");

        nomeC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nomeCActionPerformed(evt);
            }
        });

        jLabel7.setText("    Data:");

        jLabel8.setText("    taxa cobrada (Em Reais):");

        taxa.setText("12");

        jButton3.setText("Filtrar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        tabela.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nome", "Valor Original", "Valor Convertido", "Taxa cobrada", "Data"
            }
        ));
        jScrollPane1.setViewportView(tabela);

        NomeTemp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NomeTempActionPerformed(evt);
            }
        });

        jLabel9.setText("Nome:");

        jLabel10.setText("Data:");

        jLabel11.setText("Valor total das operações:");

        jvalorT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jvalorTActionPerformed(evt);
            }
        });

        jLabel12.setText("Valor total das Taxas:");

        jButton4.setText("Apagar Filtro");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(Caixa)
                    .addComponent(MoedaO, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(MoedaD, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 609, Short.MAX_VALUE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(66, 66, 66))
                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(nomeC)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(data, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(49, 49, 49)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(taxa)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9)
                            .addComponent(jLabel10))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(NomeTemp)
                            .addComponent(DataTemp, javax.swing.GroupLayout.DEFAULT_SIZE, 124, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE)
                            .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jvalorT, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(TaxaCobrada, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addGap(18, 18, 18)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(nomeC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Caixa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(taxa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(data, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(MoedaO, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(MoedaD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(NomeTemp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButton3)
                        .addComponent(jButton1))
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(DataTemp, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton2)
                            .addComponent(jButton4)))
                    .addComponent(jLabel10))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(jvalorT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12)
                    .addComponent(TaxaCobrada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void CaixaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CaixaActionPerformed

    }//GEN-LAST:event_CaixaActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if (nomeC.getText().equals("") || Caixa.getText().equals("") || taxa.getText().equals("") || data.getDate() == null) {
            JOptionPane.showMessageDialog(null, "Insira valores em todos os caompos!");
        } else {
            try {
                double valor = 0;
                num = parseFloat(Caixa.getText());
                tax = parseFloat(taxa.getText());

                if (MoedaO.getSelectedItem().equals("Real (BRL)")) {
                    if (MoedaD.getSelectedItem().equals("Dolar (USD)")) {
                        valor = num * 0.19;
                        JOptionPane.showMessageDialog(null, "O valor da conversão foi de: " + valor + " Dólares");
                    }//real em dolar 
                    if (MoedaD.getSelectedItem().equals("Euro (EUR)")) {
                        valor = num * 0.16;
                        JOptionPane.showMessageDialog(null, "O valor da conversão foi de: " + valor + " Euros");
                    }//real em euro
                    if (MoedaD.getSelectedItem().equals("Peso Chileno (CLP)")) {
                        valor = num * 133.36;
                        JOptionPane.showMessageDialog(null, "O valor da conversão foi de: " + valor + " Pesos Chilenos");
                    }//real em peso chileno
                    if (MoedaD.getSelectedItem().equals("Real (BRL)")) {
                        JOptionPane.showMessageDialog(null, "Erro: Não há como converter!");
                    }
                } //real

                if (MoedaO.getSelectedItem().equals("Dolar (USD)")) {
                    if (MoedaD.getSelectedItem().equals("Real (BRL)")) {
                        valor = num * 5.30;
                        JOptionPane.showMessageDialog(null, "O valor da conversão foi de: " + valor + " Reais");
                    }
                    if (MoedaD.getSelectedItem().equals("Euro (EUR)")) {
                        valor = num * 0.83;
                        JOptionPane.showMessageDialog(null, "O valor da conversão foi de: " + valor + " Euros");
                    }
                    if (MoedaD.getSelectedItem().equals("Peso Chileno (CLP)")) {
                        valor = num * 707.80;
                        JOptionPane.showMessageDialog(null, "O valor da conversão foi de: " + valor + " Pesos Chilenos");
                    }
                    if (MoedaD.getSelectedItem().equals("Dolar (USD)")) {
                        JOptionPane.showMessageDialog(null, "Erro: Não há como converter!");
                    }
                } // dolar

                if (MoedaO.getSelectedItem().equals("Euro (EUR)")) {
                    if (MoedaD.getSelectedItem().equals("Real (BRL)")) {
                        valor = num * 6.41;
                        JOptionPane.showMessageDialog(null, "O valor da conversão foi de: " + valor + " Reais");
                    }
                    if (MoedaD.getSelectedItem().equals("Dolar (USD)")) {
                        valor = num * 1.21;
                        JOptionPane.showMessageDialog(null, "O valor da conversão foi de: " + valor + " Dólares");
                    }
                    if (MoedaD.getSelectedItem().equals("Peso Chileno (CLP)")) {
                        valor = num * 854.82;
                        JOptionPane.showMessageDialog(null, "O valor da conversão foi de: " + valor + " Pesos Chilenos");
                    }
                    if (MoedaD.getSelectedItem().equals("Euro (EUR)")) {
                        JOptionPane.showMessageDialog(null, "Erro: Não há como converter!");
                    }
                } // Euro

                if (MoedaO.getSelectedItem().equals("Peso Chileno (CLP)")) {
                    if (MoedaD.getSelectedItem().equals("Real (BRL)")) {
                        valor = num * 0.0075;
                        JOptionPane.showMessageDialog(null, "O valor da conversão foi de: " + valor + " Reais");
                    }
                    if (MoedaD.getSelectedItem().equals("Dolar (USD)")) {
                        valor = num * 0.0014;
                        JOptionPane.showMessageDialog(null, "O valor da conversão foi de: " + valor + " Dólares");
                    }
                    if (MoedaD.getSelectedItem().equals("Euro (EUR)")) {
                        valor = num * 0.0012;
                        JOptionPane.showMessageDialog(null, "O valor da conversão foi de: " + valor + " Euros");
                    }
                    if (MoedaD.getSelectedItem().equals("Peso Chileno (CLP)")) {
                        JOptionPane.showMessageDialog(null, "Erro: Não há como converter!");
                    }
                }//peso chileno   
                if (MoedaO.getSelectedItem().equals("Real (BRL)")) {
                    valorT = valorT + num;
                    jvalorT.setText("R$ " + String.valueOf(valorT));
                } else if (MoedaO.getSelectedItem().equals("Dolar (USD)")) {
                    valorTemp = num;
                    valorTemp = valorTemp * 5.30;
                    valorT = valorT + valorTemp;
                    jvalorT.setText("R$ " + String.valueOf(valorT));
                } else if (MoedaO.getSelectedItem().equals("Euro (EUR)")) {
                    valorTemp = num;
                    valorTemp = valorTemp * 6.41;
                    valorT = valorT + valorTemp;
                    jvalorT.setText("R$ " + String.valueOf(valorT));
                } else if (MoedaO.getSelectedItem().equals("Peso Chileno (CLP)")) {
                    valorTemp = num;
                    valorTemp = valorTemp * 0.0075;
                    valorT = valorT + valorTemp;
                    jvalorT.setText("R$ " + String.valueOf(valorT));
                } 
                taxaC = tax + taxaC;
                TaxaCobrada.setText(String.valueOf(taxaC));

                nomeP.add(nomeC.getText());
                moedaPO = (String) MoedaO.getSelectedItem();
                moedaPC = (String) MoedaD.getSelectedItem();
                valorPO = num;
                valorPC = valor;
                taxaP.add(taxa.getText());
                dataC.add(data.getDate());

                ajusteO.add(valorPO + " " + moedaPO);
                ajusteD.add(valorPC + " " + moedaPC);

                DefaultTableModel tabelinha = (DefaultTableModel) tabela.getModel();
                Object[] dados = {nomeC.getText(), num + " " + MoedaO.getSelectedItem(), valor + " " + MoedaD.getSelectedItem(), taxa.getText(), data.getDate()};
                tabelinha.addRow(dados);

            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Erro: Não foi possivel converter!\n caso entreja usando um número com virgula, substitua-o por '.' ");
            }
        }
    }//GEN-LAST:event_jButton1ActionPerformed


    private void MoedaOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MoedaOActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MoedaOActionPerformed

    private void MoedaDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MoedaDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MoedaDActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

        JOptionPane.showMessageDialog(null, "O código desse programa foi realizado na NETBEANS IDE 8.2 por Marcos da Silva Bagatini\n As informações referentes à cambio foram retiradas ta tabela de conversão de valores do próprio google no dia 12/05/2021\n Qualquer dúvida pode ser tirada no email: marcosbagatinii@gmail.com");


    }//GEN-LAST:event_jButton2ActionPerformed

    private void nomeCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nomeCActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nomeCActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        DefaultTableModel tabelinha = (DefaultTableModel) tabela.getModel();
        String nomeT = NomeTemp.getText();
        Date dataT = DataTemp.getDate();
        boolean valido = false;
        
        if (NomeTemp.getText().equals("") && DataTemp.getDate() == null) {
            JOptionPane.showMessageDialog(null, "Erro: Insira algum valor em pelo menos um dos campos! ");
        } else {
            if (nomeP.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Erro: Tenha pelo menos um registro antes de filtrar ");
            } else {
                tabelinha.setNumRows(0);
                for (int i = 0; i < nomeP.size(); i++) {
                    if (!NomeTemp.getText().equals("") && DataTemp.getDate() != null) {
                        if (nomeT.equalsIgnoreCase(nomeP.get(i)) && dataT.equals(dataC.get(i))) {
                            Object[] dados = {nomeP.get(i), ajusteO.get(i), ajusteD.get(i), taxaP.get(i), dataC.get(i)};
                            tabelinha.addRow(dados);
                            valido = true;
                        }
                    } else {
                        if (!NomeTemp.getText().equals("")) {
                            if (nomeT.equalsIgnoreCase(nomeP.get(i))) {
                                Object[] dados = {nomeP.get(i), ajusteO.get(i), ajusteD.get(i), taxaP.get(i), dataC.get(i)};
                                tabelinha.addRow(dados);
                                valido = true;
                            }
                        } else {
                            if (dataT.equals(dataC.get(i))) {
                                Object[] dados = {nomeP.get(i), ajusteO.get(i), ajusteD.get(i), taxaP.get(i), dataC.get(i)};
                                tabelinha.addRow(dados);
                                valido = true;
                            }
                        }
                    }
                }
                if (valido == false) {
                    tabelinha.setNumRows(0);
                    JOptionPane.showMessageDialog(null, "Sua busca não retornou nenhum resultado!");
                }
            }
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void NomeTempActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NomeTempActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NomeTempActionPerformed

    private void jvalorTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jvalorTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jvalorTActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        DefaultTableModel tabelinha = (DefaultTableModel) tabela.getModel();
        tabelinha.setNumRows(0);
        for (int i = 0; i < nomeP.size(); i++) {
            Object[] dados = {nomeP.get(i), ajusteO.get(i), ajusteD.get(i), taxaP.get(i), dataC.get(i)};
            tabelinha.addRow(dados);

        }


    }//GEN-LAST:event_jButton4ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Interface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Interface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Interface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Interface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Interface().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Caixa;
    private com.toedter.calendar.JDateChooser DataTemp;
    private javax.swing.JComboBox<String> MoedaD;
    private javax.swing.JComboBox<String> MoedaO;
    private javax.swing.JTextField NomeTemp;
    private javax.swing.JTextField TaxaCobrada;
    private com.toedter.calendar.JDateChooser data;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jvalorT;
    public javax.swing.JTextField nomeC;
    private javax.swing.JTable tabela;
    private javax.swing.JTextField taxa;
    // End of variables declaration//GEN-END:variables

    
}
